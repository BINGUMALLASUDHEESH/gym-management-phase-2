package com.servelets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.DMLoperations.participant_session_operations;
import com.entity.add_participant_session;

/**
 * Servlet implementation class addparticipantsession
 */
public class addparticipantsession extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public addparticipantsession() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		if (request.getAttribute("processed") != null) {
            // Request already processed, ignore
            return;
        }
		
		String participantId = request.getParameter("participant");
        String sessionId = request.getParameter("session");
        String batchId = request.getParameter("batchdata");
        
        
        System.out.println(participantId+"//"+sessionId+"//"+batchId);
        
        
        request.setAttribute("processed", true);
        add_participant_session aps=new add_participant_session();
        
        aps.setPid(Integer.parseInt(participantId));
        aps.setSessionid(Integer.parseInt(sessionId));
        aps.setGroupid(Integer.parseInt(batchId));
        
        try {
			participant_session_operations pso=new participant_session_operations();
			String res=pso.add(aps);
			if(res.equalsIgnoreCase("sucess")) {
				System.err.println("added");
				response.sendRedirect("all_participant_session.jsp");
			}
			else {
				System.out.println("error");
				response.sendRedirect("add_participant_session.jsp");
			}
			
		} 
        catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
    
      //  request.getRequestDispatcher("all_participant_session.jsp").forward(request, response);

		
	}

}
