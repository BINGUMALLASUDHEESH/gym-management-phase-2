package com.servelets;

import java.io.IOException;
import java.sql.Date;
import java.time.LocalDate;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.DMLoperations.Operations;
import com.entity.participant;

/**
 * Servlet implementation class update_part_details
 */
public class update_part_details extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public update_part_details() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String id=request.getParameter("pid");
		int pid=Integer.parseInt(id);
		String name = request.getParameter("name");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String plan = request.getParameter("plan");
        String amount = request.getParameter("amount");
        String startDate = request.getParameter("startdate");
    
        
        
        //System.out.println(pid+"//"+name+"//"+email+"//"+phone+"//"+plan+"//"+amount+"//"+startDate+"//"+password);
        
        LocalDate start = LocalDate.parse(startDate);
        LocalDate endDate = start.plusMonths(Integer.parseInt(plan));
        
        Date sqlStartDate = Date.valueOf(start);
        Date sqlEndDate = Date.valueOf(endDate);
        
        participant p=new participant();
        p.setName(name);
        p.setEmail(email);
        p.setPhone(phone);
        p.setPlan(plan);
        p.setAmount(Integer.parseInt(amount));
        p.setStartDate(sqlStartDate);
        p.setEndDate(sqlEndDate);
      //  p.setSessionid(Integer.parseInt(session));
      //  p.setGroupid(Integer.parseInt(batch));
		
		
		try {
			Operations op=new Operations();
			String res=op.updatedet(p,pid);
			if(res.equalsIgnoreCase("success")) {
				//System.out.println("updated"); 
			} 
		} 
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		 response.sendRedirect("allparticipant.jsp");
	}

	
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
