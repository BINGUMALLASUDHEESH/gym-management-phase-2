package com.servelets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.DMLoperations.Operations;

/**
 * Servlet implementation class delete_part
 */
public class delete_part extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public delete_part() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String id=request.getParameter("part_id");	
		
		
		try {
			Operations op=new Operations();
			int res=op.deletepart(Integer.parseInt(id));
			//System.out.println(res);
			} catch (Exception e) {
			
			e.printStackTrace();
		}
		
		
		
		response.sendRedirect("allparticipant.jsp");
		
	}

}
