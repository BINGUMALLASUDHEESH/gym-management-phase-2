package com.servelets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.DMLoperations.BatchOperations;

/**
 * Servlet implementation class delete_batch
 */
public class delete_batch extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public delete_batch() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String id=request.getParameter("batchid");
		
		System.out.println(id);
		
		try {
			BatchOperations bop=new BatchOperations();
			String res=bop.deletebatch(Integer.parseInt(id));
			if(res.equalsIgnoreCase("sucess")) {
				System.out.println("deleted batch");
			}
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		
		response.sendRedirect("allbatch.jsp");
	}
	

}
