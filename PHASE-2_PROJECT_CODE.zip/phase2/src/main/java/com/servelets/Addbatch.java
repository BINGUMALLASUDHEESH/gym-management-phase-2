package com.servelets;

import java.io.IOException;
import java.util.Date;
import java.sql.Time;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.DMLoperations.BatchOperations;
import com.entity.batch;

/**
 * Servlet implementation class Addbatch
 */
public class Addbatch extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public Addbatch() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String session = request.getParameter("session");
        String starttimestr = request.getParameter("starttime");
        String endtimestr = request.getParameter("endtime");
        
		
        
        
        Time starttime=null,endtime=null;
        
		try {
			 SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
			    Date date = sdf.parse(starttimestr);
			    starttime = new Time(date.getTime());
			    Date enddate = sdf.parse(endtimestr);
			    endtime = new Time(enddate.getTime());
			
			
			batch b=new batch();
			 
			b.setSessionid(Integer.parseInt(session));
			b.setStarttime(starttime);
			b.setEndtime(endtime);
			
			
		//	System.out.println("start time"+starttime);
	      //  System.out.println("ending time"+endtime);
			
			BatchOperations bop=new BatchOperations();
			String res=bop.Addbatch(b);
			
			if(res.equalsIgnoreCase("sucess"))
				System.out.println("batch ino added ");
			else
				System.out.println("batch info not added"); 
			
		} 
		catch (ParseException e) {
			
			e.printStackTrace();
		} 
		catch (Exception e) {
			
			e.printStackTrace();
		}
		
		response.sendRedirect("Addbatch.jsp");
		
	}

	
	
	
	
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
