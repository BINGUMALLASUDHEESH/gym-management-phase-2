package com.entity;

/*
 * CREATE TABLE batchinfo (
    groupid INT AUTO_INCREMENT PRIMARY KEY,
    sessionid INT, 
    starttime TIME,
    endtime TIME,
    INDEX (sessionid),
    INDEX (groupid)
);
*/



import java.sql.Time;

public class batch {
	
	private int sessionid ;
	private Time starttime;
	private Time endtime;
	private int groupid;
	
	
	
	public int getSessionid() {
		return sessionid;
	}
	public void setSessionid(int sessionid) {
		this.sessionid = sessionid;
	}
	public Time getStarttime() {
		return starttime;
	}
	public void setStarttime(Time starttime) {
		this.starttime = starttime;
	}
	public Time getEndtime() {
		return endtime;
	}
	public void setEndtime(Time endtime) {
		this.endtime = endtime;
	}
	public int getGroupid() {
		return groupid;
	}
	public void setGroupid(int groupid) {
		this.groupid = groupid;
	}
	
	
	
	
	
	
}
