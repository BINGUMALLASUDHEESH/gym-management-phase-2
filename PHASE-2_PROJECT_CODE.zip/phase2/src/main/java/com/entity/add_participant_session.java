package com.entity;

/*
  CREATE TABLE participant_session (
    participant_id INT,
    session_id INT,
    group_id INT,
    PRIMARY KEY (participant_id, group_id), -- Define composite primary key
    FOREIGN KEY (participant_id) REFERENCES participantinfo(id) ON DELETE CASCADE,
    FOREIGN KEY (group_id) REFERENCES batchinfo(groupid) ON DELETE CASCADE
);
*/


public class add_participant_session {

	private int pid;
	private int sessionid;
	private int groupid;
	
	
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public int getSessionid() {
		return sessionid;
	}
	public void setSessionid(int sessionid) {
		this.sessionid = sessionid;
	}
	public int getGroupid() {
		return groupid;
	}
	public void setGroupid(int groupid) {
		this.groupid = groupid;
	}
	
	
	
	
}
