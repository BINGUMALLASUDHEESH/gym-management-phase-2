package com.connection;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBconnection {

	public static Connection getConnection() throws Exception
	{
		Connection conn = null;
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/sample","root", "sudheesh");
			
						
		} catch (Exception e) {
			conn = null;
			System.out.println(e);
		}

		return conn;
	}
	
}
