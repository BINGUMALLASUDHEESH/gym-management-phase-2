package com.DMLoperations;

import java.sql.Connection; 
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.connection.DBconnection;
import com.entity.batch;

public class BatchOperations {

	
	private Connection connection=null;
	private PreparedStatement stmt;
	
	public  BatchOperations() throws Exception {
		
		connection=DBconnection.getConnection();
		
	}
	
	public String Addbatch(batch b) {
		String res="";
		try {
            String query = "insert into batchinfo (sessionid, starttime, endtime) values (?, ?, ?)";
            stmt = connection.prepareStatement(query);
            stmt.setInt(1, b.getSessionid());
            stmt.setTime(2, b.getStarttime());
            stmt.setTime(3, b.getEndtime());
           

            int added = stmt.executeUpdate();
            if(added>=1)
            	res="sucess";
	
		}
		catch (Exception e) {
				res="null";
		}
		return res;
	}
	
	
	public List<batch> viewall()
	{
		List<batch> allbatch=new ArrayList<batch>();
		try {
			String sql="select * from batchinfo";
			stmt=connection.prepareStatement(sql);
			ResultSet resset=stmt.executeQuery();
			
			while (resset.next()) {
	            batch b = new batch();
	           
	            b.setSessionid(resset.getInt("sessionid"));
	            b.setStarttime(resset.getTime("starttime"));
	            b.setEndtime(resset.getTime("endtime"));
	            b.setGroupid(resset.getInt("groupid"));
	            
	            allbatch.add(b);
	        }
		} 
		catch (Exception e) {
			
		}
		return allbatch;
		
		
	}
	
	public String deletebatch(int id) {
		
		String res="";
		
		try {
			String sql="delete from batchinfo where groupid=?";
			stmt=connection.prepareStatement(sql);
			stmt.setInt(1, id);
			int out=stmt.executeUpdate();
			if(out>=1)
				res="sucess";
		} catch (Exception e) {
			res="error";
		}
		return res;
	}
	
}
