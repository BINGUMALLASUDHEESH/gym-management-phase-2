package com.DMLoperations;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.connection.DBconnection;
import com.entity.add_participant_session;
import com.mysql.cj.xdevapi.Result;

public class participant_session_operations {

	private Connection connection=null;
	private PreparedStatement stmt;
	
	public  participant_session_operations() throws Exception {
		
		connection=DBconnection.getConnection();
		
	}
	
	public String add(add_participant_session aps) throws SQLException {
		String res="";
		
		String query = "insert into participant_session (participant_id, session_id, group_id) values (?, ?, ?)";
        stmt = connection.prepareStatement(query);
        stmt.setInt(1, aps.getPid() );
        stmt.setInt(2, aps.getSessionid() );
        stmt.setInt(3, aps.getGroupid());
        
        
        int sol= stmt.executeUpdate();
        if(sol>=1)
        	res="success";
        else
        	res="error";
        
		return res;
	}
	
	public List<add_participant_session> viewall() throws SQLException{
		
		List<add_participant_session> all=new ArrayList<add_participant_session>();
		
		String sql="select * from participant_session";
		stmt=connection.prepareStatement(sql);
		ResultSet resset=stmt.executeQuery();
		
		while(resset.next()) {
			
			add_participant_session aps=new add_participant_session();
			
			aps.setPid(resset.getInt("participant_id"));
			aps.setSessionid(resset.getInt("session_id"));
			aps.setGroupid(resset.getInt("group_id"));
			
			all.add(aps);
		}
		
		return all;
	}
	
}
