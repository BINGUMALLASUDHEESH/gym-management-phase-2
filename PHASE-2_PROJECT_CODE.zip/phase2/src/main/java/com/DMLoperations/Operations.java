package com.DMLoperations;

import java.sql.Connection;  
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.connection.DBconnection;
import com.entity.participant;

public class Operations {

	private Connection connection=null;
	private PreparedStatement stmt;
	
	public Operations() throws Exception {
		
		connection=DBconnection.getConnection();
		
	}
	
	public String Addpart(participant p) throws SQLException {
		String res = "error";
		try {
		String sql = "insert into participantinfo(name,email,phone,gender,plan_in_months,amount,startdate,enddate) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
		stmt = connection.prepareStatement(sql);
		
		stmt.setString(1, p.getName());
        stmt.setString(2, p.getEmail());
        stmt.setString(3, p.getPhone());
        stmt.setString(4, p.getGender());
        stmt.setString(5, p.getPlan());
        stmt.setInt(6, p.getAmount());   
        stmt.setDate(7, p.getStartDate());
        stmt.setDate(8, p.getEndDate());
       
        
        int ch = stmt.executeUpdate();
		if(ch>=1) 
			res = "success";
		} catch (Exception e) {
				res = "error";
				System.out.println(e);
		}
		return res;
		
	}
	
	public List<participant> viewall() throws SQLException{
		
		List<participant> allparticipant= new ArrayList<participant>();
		stmt=connection.prepareStatement("select * from participantinfo");
		
		ResultSet resultset=stmt.executeQuery();
		
		while (resultset.next()) {
			
			participant p = new participant();
	        
	        p.setId(resultset.getInt("id"));
	        p.setName(resultset.getString("name"));
	        p.setEmail(resultset.getString("email"));
	        p.setPhone(resultset.getString("phone"));
	        p.setGender(resultset.getString("gender"));
	        p.setPlan(resultset.getString("plan_in_months"));
	        p.setAmount(resultset.getInt("amount"));
	        p.setStartDate(resultset.getDate("startdate"));
	        p.setEndDate(resultset.getDate("enddate"));
	       
	       
	        allparticipant.add(p);
	    }
		
		return allparticipant;
	}
	
	public int deletepart(int id) throws SQLException {
	    int result = 0;
	    try {
	        String sql = "delete from participantinfo where id = ?";
	        stmt = connection.prepareStatement(sql);
	        stmt.setInt(1, id);
	        result = stmt.executeUpdate();
	    } 
	    catch (Exception e) {
	        e.printStackTrace();
	    }
	    return result;
	}
	
	
	public participant search(int id) {
		
		participant p= new participant();
		
		try {
	        String sql = "select * from participantinfo where id = ?";
	        stmt = connection.prepareStatement(sql);
	        stmt.setInt(1, id);
	        ResultSet resset=stmt.executeQuery();
	        if(resset.next()) {
	        
	        	p.setId(resset.getInt("id"));
		        p.setName(resset.getString("name"));
		        p.setEmail(resset.getString("email"));
		        p.setPhone(resset.getString("phone"));
		        p.setGender(resset.getString("gender"));
		        p.setPlan(resset.getString("plan_in_months"));
		        p.setAmount(resset.getInt("amount"));
		        p.setStartDate(resset.getDate("startdate"));
		        p.setEndDate(resset.getDate("enddate"));
		       
	        	
	        }
	    } 
	    catch (Exception e) {
	    	System.out.println(e+"data not found");
	        e.printStackTrace();
	    }
		
		return p;
	}
	
	
	public String updatedet(participant p,int id) throws SQLException {
		
		
        try {
        	String sql="update participantinfo set name=?,email=?,phone=?,plan_in_months=?,amount=?, startdate=?, enddate=? where id=?";
    		stmt = connection.prepareStatement(sql);

            stmt.setString(1, p.getName());
            stmt.setString(2, p.getEmail());
            stmt.setString(3, p.getPhone());
            stmt.setString(4, p.getPlan());
            stmt.setInt(5, p.getAmount());
            stmt.setDate(6, p.getStartDate());
            stmt.setDate(7, p.getEndDate());
           
            stmt.setInt(8, id);
            
            
            int output=stmt.executeUpdate();
            
            if(output>=1)
            	return "success";
            
		} catch (Exception e) {
			// TODO: handle exception
		}
        
		return "error";
		
	}

}
